<!-- PROJECT LOGO -->
<br />
<div align="center">
  <a href="#">
    <img src="https://image.freepik.com/free-vector/triangle-letter-ag-free-logo-design_8035-1.jpg" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">Easy Consulting</h3>

  <p align="center">
    A Technonogly agency fullstack website build in react, mui , bootstrap and nodejs 
   
  </p>
</div>


## Tech Stack
- [React](https://facebook.github.io/react/)
- [JavaScripp(ES6)](https://facebook.github.io/react/)
- [Firebase](https://firebase.google.com/)
- [Firestore](https://firebase.google.com/docs/firestore)
- [Firebase Authentication](https://firebase.google.com/docs/auth)
- [Material-UI](https://material-ui.com/)
- [Webpack](https://webpack.js.org/)
- [FileSaver](https://www.npmjs.com/package/file-saver)
- [React-Bootstrape](#)
- [Context API](#)
- [stripe](#)
- [React-router-dom v-6](#)
- [Express](#)
- [MongoDb](#)
- [Node.js](#)
- [More...](#)


 
<!-- CONTRIBUTING -->
## Contributing

Contributions are what make the open source community such an amazing place to learn, inspire, and create. Any contributions you make are **greatly appreciated**.

If you have a suggestion that would make this better, please fork the repo and create a pull request. You can also simply open an issue with the tag "enhancement".
Don't forget to give the project a star! Thanks again!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

<!-- ABOUT THE PROJECT -->
## Features
This is fullstack softawre agency project. i have build this site in my leisure time only cool. that's why did'nt have much time added much functionalilty. but in future i will try add here more things.
here i have implement context api for data handling. my plan was using redux or graphql using. but this is only testing project and i have time conflict that's why can't add that features.
also love to add typeScript. right now my machine taking little time while compile typescript file, it's too hard me that using that site without typescript.

What you get here:
* implement responsive ui with first loading including backend
* * MUI provides  styling and building Material-UI components quickly and easily
* Most of the UI created react-bootstrap as well row css.
* Few cases used MUI but in future i will add more MUI features here.:smile:
* Responsive landing page.
* user can give review, can purchase a product and see there status.
* there most interting part is Login Page. this is amazing design and authentication system.
* job portal site.
* all the input are have to validate.
* authenttication system(login, logout, signup, reset email, OTP, subscribe).
* payement system(here used only Stripe in near will add more payment gateway)
* Deffrent for Dasboard(Admin and User)
* in dashboard Admin has all kinds of access(CRUD operations, add admin, manage orders and many more)

## Contact

